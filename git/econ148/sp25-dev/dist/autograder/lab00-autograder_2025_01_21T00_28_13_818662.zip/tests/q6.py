OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> callable(print_extension)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> tel_test = {'alice': 1, 'bob': 2, 'chris': 3}\n"
                                               ">>> assert print_extension(tel_test, 'alice') == 'The extension for alice is 1.'\n"
                                               ">>> assert print_extension(tel_test, 'chris') == 'The extension for chris is 3.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
