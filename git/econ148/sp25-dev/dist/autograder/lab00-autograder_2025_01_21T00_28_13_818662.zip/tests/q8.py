OK_FORMAT = True

test = {   'name': 'q8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert q8.shape == (24, 2)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(np.sum(q8[:, 0]) / np.sum(q8[:, 1]), 22.97100987575661)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
