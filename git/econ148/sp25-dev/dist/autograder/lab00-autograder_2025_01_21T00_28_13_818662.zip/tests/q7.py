OK_FORMAT = True

test = {   'name': 'q7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert callable(squares_dict)\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> squares_test_1 = [0, 1, 2, 4]\n'
                                               '>>> squares_test_out = squares_dict(squares_test_1)\n'
                                               '>>> for e in squares_test_1:\n'
                                               '...     assert e in squares_test_out and squares_test_out[e] == e ** 2\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> squares_test_2 = [-1, 1, 30, 2]\n'
                                               '>>> squares_test_2_out = squares_dict(squares_test_2)\n'
                                               '>>> for e in squares_test_2:\n'
                                               '...     assert e in squares_test_2_out and squares_test_2_out[e] == e ** 2\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
