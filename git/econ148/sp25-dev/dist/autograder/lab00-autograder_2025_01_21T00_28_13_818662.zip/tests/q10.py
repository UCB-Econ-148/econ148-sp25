OK_FORMAT = True

test = {   'name': 'q10',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> assert sum([ord(c) for c in codeword]) ^ 966984 == 967588\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
