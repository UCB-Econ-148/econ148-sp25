OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> assert q2 == [1, 2, 3, 4, 5, 6]\n', 'hidden': False, 'locked': False}, {'code': '>>> assert q3 == [1, 2, 4, 5, 6]\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
