OK_FORMAT = True

test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert len(tel2) == 4\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert not 'bennett' in tel2\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert 'eric' in tel2\n>>> assert np.isclose(tel2['eric'], 1480)\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
