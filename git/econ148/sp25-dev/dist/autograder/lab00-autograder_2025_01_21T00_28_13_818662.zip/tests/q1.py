OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> assert q1 == [1, 2, 3, 4, 5]\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
