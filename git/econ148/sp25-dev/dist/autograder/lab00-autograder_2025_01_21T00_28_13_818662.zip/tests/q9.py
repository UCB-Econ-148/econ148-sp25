OK_FORMAT = True

test = {   'name': 'q9',
    'points': None,
    'suites': [{'cases': [{'code': '>>> assert np.isclose(q9 ^ 966984, 379797)\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
